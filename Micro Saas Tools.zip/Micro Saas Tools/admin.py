from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db, User, ToolData, AdminStats
from functools import wraps

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin access required')
            return redirect(url_for('main.home'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/admin')
@login_required
@admin_required
def dashboard():
    users = User.query.all()
    tool_data = ToolData.query.all()
    stats = AdminStats.query.first()
    if not stats:
        stats = AdminStats(total_users=len(users), total_tools_used=len(tool_data))
        db.session.add(stats)
        db.session.commit()
    return render_template('admin_dashboard.html', users=users, tool_data=tool_data, stats=stats)

@admin_bp.route('/admin/users')
@login_required
@admin_required
def manage_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@admin_bp.route('/admin/user/<int:user_id>/toggle_admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = not user.is_admin
    db.session.commit()
    flash(f'Admin status for {user.username} updated')
    return redirect(url_for('admin.manage_users'))

@admin_bp.route('/admin/user/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('Cannot delete your own account')
        return redirect(url_for('admin.manage_users'))
    db.session.delete(user)
    db.session.commit()
    flash(f'User {user.username} deleted')
    return redirect(url_for('admin.manage_users'))

@admin_bp.route('/admin/stats')
@login_required
@admin_required
def view_stats():
    stats = AdminStats.query.first()
    if not stats:
        users_count = User.query.count()
        tools_count = ToolData.query.count()
        stats = AdminStats(total_users=users_count, total_tools_used=tools_count)
        db.session.add(stats)
        db.session.commit()
    return render_template('admin_stats.html', stats=stats)
