from flask import Blueprint, render_template, request, send_file, flash, redirect, url_for
from flask_login import login_required, current_user
import os
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
import qrcode
from io import BytesIO
from models import db
from models import ToolData

tools_bp = Blueprint('tools', __name__)

UPLOAD_FOLDER = 'static/uploads'

@tools_bp.route('/resume')
@login_required
def resume_builder():
    return render_template('resume_builder.html')

@tools_bp.route('/resume/generate', methods=['POST'])
@login_required
def generate_resume():
    data = {
        'name': request.form.get('name'),
        'email': request.form.get('email'),
        'phone': request.form.get('phone'),
        'experience': request.form.get('experience'),
        'skills': request.form.get('skills')
    }

    filename = f"resume_{current_user.id}_{len(current_user.tool_data.all()) + 1}.pdf"
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    doc = SimpleDocTemplate(filepath, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph(f"<b>{data['name']}</b>", styles['Title']))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f"Email: {data['email']}", styles['Normal']))
    story.append(Paragraph(f"Phone: {data['phone']}", styles['Normal']))
    story.append(Spacer(1, 12))
    story.append(Paragraph("<b>Experience</b>", styles['Heading2']))
    story.append(Paragraph(data['experience'], styles['Normal']))
    story.append(Spacer(1, 12))
    story.append(Paragraph("<b>Skills</b>", styles['Heading2']))
    story.append(Paragraph(data['skills'], styles['Normal']))

    doc.build(story)

    tool_data = ToolData(user_id=current_user.id, tool_type='resume', data=json.dumps(data), file_path=filepath)
    db.session.add(tool_data)
    db.session.commit()

    flash('Resume generated successfully!')
    return send_file(filepath, as_attachment=True)

@tools_bp.route('/invoice')
@login_required
def invoice_generator():
    return render_template('invoice_generator.html')

@tools_bp.route('/invoice/generate', methods=['POST'])
@login_required
def generate_invoice():
    data = {
        'client_name': request.form.get('client_name'),
        'client_email': request.form.get('client_email'),
        'amount': request.form.get('amount'),
        'description': request.form.get('description'),
        'date': request.form.get('date')
    }

    filename = f"invoice_{current_user.id}_{len(current_user.tool_data.all()) + 1}.pdf"
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    c = canvas.Canvas(filepath, pagesize=letter)
    c.drawString(100, 750, "Invoice")
    c.drawString(100, 720, f"Client: {data['client_name']}")
    c.drawString(100, 700, f"Email: {data['client_email']}")
    c.drawString(100, 680, f"Amount: ${data['amount']}")
    c.drawString(100, 660, f"Description: {data['description']}")
    c.drawString(100, 640, f"Date: {data['date']}")
    c.save()

    tool_data = ToolData(user_id=current_user.id, tool_type='invoice', data=json.dumps(data), file_path=filepath)
    db.session.add(tool_data)
    db.session.commit()

    flash('Invoice generated successfully!')
    return send_file(filepath, as_attachment=True)

@tools_bp.route('/certificate')
@login_required
def certificate_generator():
    return render_template('certificate_generator.html')

@tools_bp.route('/certificate/generate', methods=['POST'])
@login_required
def generate_certificate():
    data = {
        'recipient_name': request.form.get('recipient_name'),
        'course_name': request.form.get('course_name'),
        'issuer_name': request.form.get('issuer_name'),
        'date': request.form.get('date')
    }

    filename = f"certificate_{current_user.id}_{len(current_user.tool_data.all()) + 1}.pdf"
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    c = canvas.Canvas(filepath, pagesize=letter)
    c.drawString(200, 600, "Certificate of Completion")
    c.drawString(200, 550, f"This certifies that {data['recipient_name']}")
    c.drawString(200, 520, f"has successfully completed {data['course_name']}")
    c.drawString(200, 490, f"Issued by: {data['issuer_name']}")
    c.drawString(200, 460, f"Date: {data['date']}")
    c.save()

    tool_data = ToolData(user_id=current_user.id, tool_type='certificate', data=json.dumps(data), file_path=filepath)
    db.session.add(tool_data)
    db.session.commit()

    flash('Certificate generated successfully!')
    return send_file(filepath, as_attachment=True)

@tools_bp.route('/qrcode')
@login_required
def qr_generator():
    return render_template('qr_generator.html')

@tools_bp.route('/qrcode/generate', methods=['POST'])
@login_required
def generate_qr():
    data = request.form.get('data')
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill='black', back_color='white')

    filename = f"qrcode_{current_user.id}_{len(current_user.tool_data.all()) + 1}.png"
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    img.save(filepath)

    tool_data = ToolData(user_id=current_user.id, tool_type='qrcode', data=json.dumps({'data': data}), file_path=filepath)
    db.session.add(tool_data)
    db.session.commit()

    flash('QR Code generated successfully!')
    return send_file(filepath, as_attachment=True)
