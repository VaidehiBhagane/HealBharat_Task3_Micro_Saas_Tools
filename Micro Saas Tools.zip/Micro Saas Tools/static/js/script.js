// Frontend JavaScript for Micro SaaS Tools

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(function(message) {
        setTimeout(function() {
            message.style.opacity = '0';
            setTimeout(function() {
                message.remove();
            }, 300);
        }, 5000);
    });

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    field.style.borderColor = '#ff6b6b';
                    isValid = false;
                } else {
                    field.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields.');
            }
        });
    });

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');
    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Add loading animation for form submissions with error handling
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(function(button) {
        const form = button.closest('form');
        if (!form) return;
        const originalText = button.textContent;
        form.addEventListener('submit', function(e) {
            button.textContent = 'Processing...';
            button.disabled = true;

            // Listen for form submission result
            // If the page reloads, this is not needed, but if there is an error and the page does not reload, reset the button
            window.addEventListener('error', function() {
                button.textContent = originalText;
                button.disabled = false;
            }, { once: true });

            // Fallback: re-enable after 10 seconds
            setTimeout(function() {
                button.textContent = originalText;
                button.disabled = false;
            }, 10000);
        });
    });

    // Tool card hover effects
    const toolCards = document.querySelectorAll('.tool-card, .feature-card');
    toolCards.forEach(function(card) {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Dynamic date input for invoice and certificate forms
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        const today = new Date().toISOString().split('T')[0];
        input.setAttribute('max', today);
    });

    // QR code data preview
    const qrDataInput = document.getElementById('qr_data');
    if (qrDataInput) {
        const previewDiv = document.createElement('div');
        previewDiv.id = 'qr-preview';
        previewDiv.style.marginTop = '1rem';
        previewDiv.style.padding = '1rem';
        previewDiv.style.background = 'rgba(255, 255, 255, 0.1)';
        previewDiv.style.borderRadius = '8px';
        previewDiv.style.backdropFilter = 'blur(10px)';
        qrDataInput.parentNode.appendChild(previewDiv);

        qrDataInput.addEventListener('input', function() {
            const data = this.value;
            if (data.length > 0) {
                previewDiv.innerHTML = `<strong>Preview:</strong> ${data.substring(0, 50)}${data.length > 50 ? '...' : ''}`;
            } else {
                previewDiv.innerHTML = '';
            }
        });
    }

    // Resume form character counter
    const experienceTextarea = document.getElementById('experience');
    const skillsTextarea = document.getElementById('skills');

    function addCharCounter(textarea, maxLength = 1000) {
        if (!textarea) return;

        const counter = document.createElement('div');
        counter.className = 'char-counter';
        counter.style.fontSize = '0.8rem';
        counter.style.textAlign = 'right';
        counter.style.marginTop = '0.5rem';
        counter.style.color = 'rgba(255, 255, 255, 0.7)';
        textarea.parentNode.appendChild(counter);

        function updateCounter() {
            const remaining = maxLength - textarea.value.length;
            counter.textContent = `${textarea.value.length}/${maxLength} characters`;
            if (remaining < 50) {
                counter.style.color = '#ff6b6b';
            } else {
                counter.style.color = 'rgba(255, 255, 255, 0.7)';
            }
        }

        textarea.addEventListener('input', updateCounter);
        updateCounter();
    }

    addCharCounter(experienceTextarea);
    addCharCounter(skillsTextarea);

    // Mobile menu toggle (if needed in future)
    // This can be expanded if a mobile menu is added

    console.log('Micro SaaS Tools JavaScript loaded successfully!');
});
